<?php $this->load->view($header);?>
<div class="row">
	<div class="col-xs-12">
		
		<?php $this->load->view($contents);?>

	</div><!-- /.col -->
</div><!-- /.row -->
<?php $this->load->view($footer);?>